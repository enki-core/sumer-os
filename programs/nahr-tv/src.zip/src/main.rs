slint::include_modules!();
use slint::ComponentHandle;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

fn main() -> Result<(), slint::PlatformError> {
    let main_window = MainWindow::new()?;
    
    // Connect Back Click to exit the application and return to desktop
    main_window.on_back_clicked(move || {
        println!("Back button clicked. Returning to Desktop...");
        std::process::exit(0);
    });

    // Bluetooth Connection Simulation
    let window_weak_bt = main_window.as_weak();
    main_window.on_bluetooth_device_clicked(move |dev| {
        let window_weak = window_weak_bt.clone();
        let dev = dev.to_string();
        
        if let Some(window) = window_weak.upgrade() {
            window.set_bluetooth_connecting(true);
            window.set_bluetooth_connection_status(format!("جاري الاقتران مع {}...", dev).into());
        }

        thread::spawn(move || {
            thread::sleep(Duration::from_millis(1500));
            let window_weak_s1 = window_weak.clone();
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(window) = window_weak_s1.upgrade() {
                    window.set_bluetooth_connection_status("تم الاقتران بنجاح! 🔵".into());
                }
            });

            thread::sleep(Duration::from_millis(1000));
            let _ = slint::invoke_from_event_loop(move || {
                if let Some(window) = window_weak.upgrade() {
                    window.set_bluetooth_connecting(false);
                    window.set_show_settings(false);
                }
            });
        });
    });

    // Play Navigation Sound Callback
    main_window.on_play_navigation_sound(move || {
        thread::spawn(move || {
            let paths = vec![
                "ui/firmament/assets/audio.mp3",
                "/usr/bin/firmament/assets/audio.mp3",
                "sumer-ui/ui/firmament/assets/audio.mp3",
                "/usr/share/sumer/audio.mp3",
                "programs/sumer-ui/ui/firmament/assets/audio.mp3",
            ];
            let mut sound_path = "ui/firmament/assets/audio.mp3".to_string();
            for p in &paths {
                if std::path::Path::new(p).exists() {
                    sound_path = p.to_string();
                    break;
                }
            }
            if std::process::Command::new("gst-play-1.0").arg(&sound_path).spawn().is_ok() { return; }
            if std::process::Command::new("mpg123").arg("-q").arg(&sound_path).spawn().is_ok() { return; }
            if std::process::Command::new("pw-play").arg(&sound_path).spawn().is_ok() { return; }
            if std::process::Command::new("paplay").arg(&sound_path).spawn().is_ok() { return; }
            if std::process::Command::new("ffplay").args(&["-nodisp", "-autoexit", "-loglevel", "quiet", &sound_path]).spawn().is_ok() { return; }
        });
    });

    // App launch handling from the Android TV launcher grid
    main_window.on_app_clicked(move |app_name| {
        let app_name = app_name.to_string();
        println!("Launch app from Android TV: {}", app_name);
        
        let binary_path = match app_name.as_str() {
            "Console" | "💻" | "شيل دجلة" => "/usr/bin/tigris-shell",
            "Store" | "zaqura-store" => "/usr/bin/zaqura-store",
            "Notepad" | "alwah-notepad" => "/programs/alwah-notepad/run",
            "Browser" | "orok-browser" => "/programs/orok-browser/run",
            "Shutdown" | "إغلاق" => {
                std::process::Command::new("poweroff").spawn().ok();
                std::process::exit(0);
            }
            _ => return,
        };

        let mut actual_path = binary_path.to_string();
        if !std::path::Path::new(&actual_path).exists() {
            actual_path = match app_name.as_str() {
                "Console" | "💻" | "شيل دجلة" => "../tigris-shell/target-alpine/release/tigris-shell".to_string(),
                "Store" | "zaqura-store" => "../zaqura-store/target-alpine/release/zaqura-store".to_string(),
                _ => return,
            };
        }

        if std::path::Path::new(&actual_path).exists() {
            std::process::Command::new(&actual_path).spawn().ok();
        }
    });

    // Timers for volume and brightness
    let window_weak = main_window.as_weak();
    let timer_active = Arc::new(Mutex::new(0u32));
    let timer_active_clone = timer_active.clone();
    main_window.on_trigger_volume_timer(move || {
        let window_weak = window_weak.clone();
        let timer_active = timer_active_clone.clone();
        
        let mut session = timer_active.lock().unwrap();
        *session += 1;
        let current_session = *session;
        drop(session);
        
        thread::spawn(move || {
            thread::sleep(Duration::from_secs(3));
            let session = timer_active.lock().unwrap();
            if *session == current_session {
                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(window) = window_weak.upgrade() {
                        window.set_show_volume_bar(false);
                    }
                });
            }
        });
    });

    let window_weak_brightness = main_window.as_weak();
    let timer_active_brightness = Arc::new(Mutex::new(0u32));
    let timer_active_brightness_clone = timer_active_brightness.clone();
    main_window.on_trigger_brightness_timer(move || {
        let window_weak = window_weak_brightness.clone();
        let timer_active = timer_active_brightness_clone.clone();
        
        let mut session = timer_active.lock().unwrap();
        *session += 1;
        let current_session = *session;
        drop(session);
        
        thread::spawn(move || {
            thread::sleep(Duration::from_secs(3));
            let session = timer_active.lock().unwrap();
            if *session == current_session {
                let _ = slint::invoke_from_event_loop(move || {
                    if let Some(window) = window_weak.upgrade() {
                        window.set_show_brightness_bar(false);
                    }
                });
            }
        });
    });

    // Real-time clock synchronization
    let window_weak_time = main_window.as_weak();
    let initial_time = std::process::Command::new("date")
        .arg("+%I:%M %p")
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string().to_uppercase())
        .unwrap_or_else(|_| "12:00 PM".to_string());
    main_window.set_current_time(initial_time.into());

    let time_timer = slint::Timer::default();
    time_timer.start(slint::TimerMode::Repeated, std::time::Duration::from_secs(15), move || {
        if let Some(window) = window_weak_time.upgrade() {
            let output = std::process::Command::new("date")
                .arg("+%I:%M %p")
                .output()
                .map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string().to_uppercase())
                .unwrap_or_else(|_| "12:00 PM".to_string());
            window.set_current_time(output.into());
        }
    });

    main_window.run()
}
